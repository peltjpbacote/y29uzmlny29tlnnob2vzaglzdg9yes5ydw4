window.__require = function t(e, n, o) {
function i(a, r) {
if (!n[a]) {
if (!e[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!r && l) return l(c, !0);
if (s) return s(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = c;
}
var u = n[a] = {
exports: {}
};
e[a][0].call(u.exports, function(t) {
return i(e[a][1][t] || t);
}, u, u.exports, t, e, n, o);
}
return n[a].exports;
}
for (var s = "function" == typeof __require && __require, a = 0; a < o.length; a++) i(o[a]);
return i;
}({
BundleControl: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "042a81rvuJLIYsEHYhfH5Th", "BundleControl");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = t("./Configs"), i = t("./Global"), s = function() {
function t() {}
t.init = function(t) {
this.serverVersion = t;
};
t.loadSceneGame = function(t, e, n, o) {
this.loadBundle(t, function(t) {
t.loadScene(e, function(t, e) {
n(t, e);
}, function() {
cc.director.preloadScene(e, function(t, e) {
n(t, e);
}, function() {
cc.director.loadScene(e);
o();
});
});
});
};
t.loadPrefabGame = function(t, e, n, o) {
this.loadBundle(t, function(t) {
t.load(e, cc.Prefab, function(t, e) {
n(t, e);
}, function(e, n) {
o(n, t);
});
});
};
t.loadBundle = function(t, e) {
if (o.default.App.IS_LOCAL) {
var n = t;
cc.assetManager.loadBundle(n, function(t, n) {
null == t ? e(n) : cc.log("Error Donwload bundle:" + JSON.stringify(t));
});
} else {
var i = this.serverVersion[t];
n = t;
cc.sys.isNative && (n = i.url);
cc.assetManager.loadBundle(n, {
version: i.hash
}, function(t, n) {
null == t && e(n);
});
}
};
t.loadPrefabPopup = function(t, e) {
i.Global.BundleLobby.load(t, function(t, n) {
t || e(n);
});
};
t.serverVersion = {};
return t;
}();
n.default = s;
cc._RF.pop();
}, {
"./Configs": "Configs",
"./Global": "Global"
} ],
Configs: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "a8b148ShhNECLRCMfJf61sO", "Configs");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o, i = t("./VersionConfig");
(function(t) {
var e = function() {
function e() {}
e.clear = function() {
this.UserId = 0;
this.Username = "";
this.Password = "";
this.Nickname = "";
this.TokenPayment = "";
this.Avatar = "";
this.Mail = "";
this.Coin = 0;
this.CoinV8 = 0;
this.IsLogin = !1;
this.AccessToken = "";
this.AccessToken2 = "";
this.SessionKey = "";
this.CreateTime = "";
this.Birthday = "";
this.IpAddress = "";
this.VipPoint = 0;
this.VipPointSave = 0;
this.CoinFish = 0;
this.UserIdFish = 0;
this.UsernameFish = "";
this.PasswordFish = "";
this.BitcoinToken = "";
this.PhoneNumner = "";
this.SAFE = 0;
};
e.getVipPointName = function() {
for (var e = this.VipPoints.length - 1; e >= 0; e--) if (t.Login.VipPoint > this.VipPoints[e]) return this.VipPointsName[e + 1];
return this.VipPointsName[0];
};
e.GetListMailNew = function() {
if (null == this.ListMail || 0 == this.ListMail.length) return 0;
for (var t = 0, e = 0; e < this.ListMail.length; e++) 0 == this.ListMail[e].status && t++;
return t;
};
e.getVipPointNextLevel = function() {
for (var e = this.VipPoints.length - 1; e >= 0; e--) if (t.Login.VipPoint > this.VipPoints[e]) return e == this.VipPoints.length - 1 ? this.VipPoints[e] : this.VipPoints[e + 1];
return this.VipPoints[0];
};
e.getVipPointIndex = function() {
for (var e = this.VipPoints.length - 1; e >= 0; e--) if (t.Login.VipPoint > this.VipPoints[e]) return e;
return 0;
};
e.UserId = 0;
e.Username = "";
e.Password = "";
e.Nickname = "";
e.Avatar = "";
e.Coin = 0;
e.CoinV8 = 0;
e.IsLogin = !1;
e.AccessToken = "";
e.AccessToken2 = "";
e.AccessTokenFB = "";
e.FacebookID = "";
e.SessionKey = "";
e.LuckyWheel = 0;
e.CreateTime = "";
e.Birthday = "";
e.IpAddress = "";
e.VipPoint = 0;
e.Address = "";
e.VipPointSave = 0;
e.Mail = "";
e.Gender = !0;
e.RefferalCode = "";
e.VerifyMobile = !1;
e.TokenPayment = "";
e.CoinFish = 0;
e.UserIdFish = 0;
e.UsernameFish = "";
e.PasswordFish = "";
e.FishConfigs = null;
e.BitcoinToken = "";
e.UserType = "0";
e.PhoneNumner = "";
e.SAFE = 0;
e.ListBankRut = null;
e.ListPayment = null;
e.ClickPayPayment = null;
e.CACHE_AG = !1;
e.CACHE_IBC = !1;
e.CACHE_WM = !1;
e.ListMail = null;
e.VipPoints = [ 5e3, 8e4, 45e4, 286e4, 886e4, 1286e4, 8286e4, 11286e4, 88886e4 ];
e.VipPointsName = [ "VIP1", "VIP2", "VIP3", "VIP4", "VIP5", "VIP6", "VIP7", "VIP8", "VIP9" ];
return e;
}();
t.Login = e;
var n = function() {
function t() {}
t.getServerConfig = function() {};
t.getPlatformName = function() {
return cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID ? "android" : cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS ? "ios" : "web";
};
t.getLinkFanpage = function() {
i.default.CPName;
return "https://www.facebook.com/w79app/";
};
t.getLinkTelegram = function() {
i.default.CPName;
return "Win365CSKH";
};
t.getLinkTelegramGroup = function() {
i.default.CPName;
return "W79GiaiTri";
};
t.init = function() {
switch (i.default.ENV) {
case i.default.ENV_DEV:
this.USE_WSS = !0;
this.API = "https://iportal." + i.default.DOMAIN_DEV + "/api";
this.MONEY_TYPE = 1;
this.LINK_DOWNLOAD = "https://" + i.default.DOMAIN_DEV;
this.LINK_EVENT = "https://" + i.default.DOMAIN_DEV + "/event";
this.HOST_MINIGAME.host = "wmini." + i.default.DOMAIN_DEV;
this.HOST_MINIGAME2.host = "wmini2." + i.default.DOMAIN_DEV;
this.HOST_TAI_XIU_MINI2.host = "overunder." + i.default.DOMAIN_DEV;
this.HOST_SLOT.host = "wslot." + i.default.DOMAIN_DEV;
this.HOST_TLMN.host = "wtlmn." + i.default.DOMAIN_DEV;
this.HOST_SHOOT_FISH.host = "wbanca." + i.default.DOMAIN_DEV;
this.HOST_SAM.host = "wsam." + i.default.DOMAIN_DEV;
this.HOST_XOCDIA.host = "wxocdia." + i.default.DOMAIN_DEV;
this.HOST_BACAY.host = "wbacay." + i.default.DOMAIN_DEV;
this.HOST_BAICAO.host = "wbaicao." + i.default.DOMAIN_DEV;
this.HOST_POKER.host = "wpoker." + i.default.DOMAIN_DEV;
this.HOST_XIDACH.host = "wxizach." + i.default.DOMAIN_DEV;
this.HOST_BINH.host = "wbinh." + i.default.DOMAIN_DEV;
this.HOST_LIENG.host = "wlieng." + i.default.DOMAIN_DEV;
break;

case i.default.ENV_PROD:
this.USE_WSS = !0;
this.API = "https://iportal." + i.default.DOMAIN_PRO + "/api";
this.MONEY_TYPE = 1;
this.LINK_DOWNLOAD = "https://" + i.default.DOMAIN_PRO;
this.LINK_EVENT = "https://" + i.default.DOMAIN_PRO + "/event";
this.HOST_MINIGAME.host = "wmini." + i.default.DOMAIN_PRO;
this.HOST_MINIGAME2.host = "wmini2." + i.default.DOMAIN_PRO;
this.HOST_TAI_XIU_MINI2.host = "overunder." + i.default.DOMAIN_PRO;
this.HOST_SLOT.host = "wslot." + i.default.DOMAIN_PRO;
this.HOST_TLMN.host = "wtlmn." + i.default.DOMAIN_PRO;
this.HOST_SHOOT_FISH.host = "wbanca." + i.default.DOMAIN_PRO;
this.HOST_SAM.host = "wsam." + i.default.DOMAIN_PRO;
this.HOST_XOCDIA.host = "wxocdia." + i.default.DOMAIN_PRO;
this.HOST_BACAY.host = "wbacay." + i.default.DOMAIN_PRO;
this.HOST_BAICAO.host = "wbaicao." + i.default.DOMAIN_PRO;
this.HOST_POKER.host = "wpoker." + i.default.DOMAIN_PRO;
this.HOST_XIDACH.host = "wxizach." + i.default.DOMAIN_PRO;
this.HOST_BINH.host = "wbinh." + i.default.DOMAIN_PRO;
this.HOST_LIENG.host = "wlieng." + i.default.DOMAIN_PRO;
break;

default:
this.USE_WSS = !0;
this.API = "https://iportal." + i.default.DOMAIN_DEV + "/api";
this.MONEY_TYPE = 1;
this.LINK_DOWNLOAD = "https://" + i.default.DOMAIN_DEV;
this.LINK_EVENT = "https://" + i.default.DOMAIN_DEV + "/event";
this.HOST_MINIGAME.host = "wmini." + i.default.DOMAIN_DEV;
this.HOST_MINIGAME2.host = "wmini2." + i.default.DOMAIN_DEV;
this.HOST_TAI_XIU_MINI2.host = "overunder." + i.default.DOMAIN_DEV;
this.HOST_SLOT.host = "wslot." + i.default.DOMAIN_DEV;
this.HOST_TLMN.host = "wtlmn." + i.default.DOMAIN_DEV;
this.HOST_SHOOT_FISH.host = "wbanca." + i.default.DOMAIN_DEV;
this.HOST_SAM.host = "wsam." + i.default.DOMAIN_DEV;
this.HOST_XOCDIA.host = "wxocdia." + i.default.DOMAIN_DEV;
this.HOST_BACAY.host = "wbacay." + i.default.DOMAIN_DEV;
this.HOST_BAICAO.host = "wbaicao." + i.default.DOMAIN_DEV;
this.HOST_POKER.host = "wpoker." + i.default.DOMAIN_DEV;
this.HOST_XIDACH.host = "wxizach." + i.default.DOMAIN_DEV;
this.HOST_BINH.host = "wbinh." + i.default.DOMAIN_DEV;
this.HOST_LIENG.host = "wlieng." + i.default.DOMAIN_DEV;
}
};
t.IS_LOCAL = !0;
t.IS_PRO = !0;
t.API = "https://iportal.365win.club/api";
t.API2 = "https://iportal2.365win.club/api";
t.APIROY = "https://portal.365win.club/api";
t.API_PAYIN_PAYWELL_BANKS = "https://iportal.eloras.icu/api/payin/paywell/banks";
t.MONEY_TYPE = 1;
t.LINK_DOWNLOAD = "https://365win.club";
t.LINK_EVENT = "https://eloras.icu/event";
t.LINK_SUPPORT = "https://eloras.icu";
t.USE_WSS = !1;
t.LINK_GROUP = "https://www.facebook.com/w79app/";
t.FB_APPID = "758971848112749";
t.AGENCY_CODE = "";
t.options = {
rememberUpgrade: !0,
transports: [ "websocket" ],
secure: !0,
rejectUnauthorized: !1,
reconnection: !0,
autoConnect: !0,
auth: {
token: "WERTWER34534FGHFGBFVBCF345234XCVASD"
}
};
t.VERSION_APP = "1.0.0";
t.GameName = {
110: "SONIC",
170: "BUMBLEBEE",
2: "Tài Xỉu",
5: "Angry Birds Mini",
11: "Tiến Lên",
160: "Angry Birds",
120: "ALITA",
150: "Sơn Tinh Thủy Tinh",
1: "MiniPoker",
3: "Bầu Cua",
9: "Ba Cây",
4: "Cao Thấp",
191: "PRIVATE KING",
190: "Tài Xỉu Siêu Tốc",
12: "Xóc Đĩa",
180: "Kho Báu Tứ Linh",
197: "BIKINI",
198: "MINI MARIO"
};
t.HOST_MINIGAME = {
host: "",
port: 443
};
t.HOST_MINIGAME2 = {
host: "",
port: 443
};
t.HOST_TAI_XIU_MINI2 = {
host: "",
port: 443
};
t.HOST_SLOT = {
host: "",
port: 443
};
t.HOST_TLMN = {
host: "",
port: 443
};
t.HOST_SHOOT_FISH = {
host: "",
port: 443
};
t.HOST_SAM = {
host: "",
port: 443
};
t.HOST_XOCDIA = {
host: "",
port: 443
};
t.HOST_BACAY = {
host: "",
port: 443
};
t.HOST_BAICAO = {
host: "",
port: 443
};
t.HOST_POKER = {
host: "",
port: 443
};
t.HOST_XIDACH = {
host: "",
port: 443
};
t.HOST_BINH = {
host: "",
port: 443
};
t.HOST_LIENG = {
host: "",
port: 443
};
t.SERVER_CONFIG = {
ratioNapThe: 1,
ratioNapMomo: 1.2,
ratioTransfer: .98,
ratioTransferDL: 1,
listTenNhaMang: [ "Viettel", "Vinaphone", "Mobifone", "Vietnamobile" ],
listIdNhaMang: [ 0, 1, 2, 3 ],
listMenhGiaNapThe: [ 1e4, 2e4, 3e4, 5e4, 1e5, 2e5, 5e5 ],
ratioRutThe: 1.2
};
t.CASHOUT_CARD_CONFIG = {
listTenNhaMang: [ "Viettel", "Vinaphone", "Mobifone", "Vietnamobile", "Garena", "Vcoin", "FPT Gate", "Mobi Data" ],
listIdNhaMang: [ "VTT", "VNP", "VMS", "VNM", "GAR", "VTC", "FPT", "DBM" ],
listMenhGiaNapThe: [ 1e4, 1e5, 2e5, 5e5 ],
listQuantity: [ "1", "2", "3" ]
};
t.TXST_SUB_TOPIC = "/topic/tx";
t.nameKeyBank = {
VCB: 0,
TCB: 1,
VIB: 2,
VPB: 3
};
return t;
}();
t.App = n;
var o = function() {
function t() {}
t.getGameName = function(t) {
switch (t) {
case this.MiniPoker:
return "MiniPoker";

case this.TaiXiu:
return "Tài xỉu";

case this.BauCua:
return "Bầu cua";

case this.CaoThap:
return "Cao thấp";

case this.Slot3x3:
return "Slot3x3";

case this.VQMM:
return "VQMM";

case this.Sam:
return "Sâm";

case this.MauBinh:
return "Mậu binh";

case this.TLMN:
return "TLMN";

case this.TaLa:
return "Tá lả";

case this.Lieng:
return "Liêng";

case this.XiTo:
return "Xì tố";

case this.XocXoc:
return "Xóc xóc";

case this.BaiCao:
return "Bài cào";

case this.Poker:
return "Poker";

case this.Bentley:
return "Bentley";

case this.RangeRover:
return "Range Rover";

case this.MayBach:
return "May Bach";

case this.RollsRoyce:
return "Rolls Royce";
}
return "Unknow";
};
t.MiniPoker = 1;
t.TaiXiu = 2;
t.BauCua = 3;
t.CaoThap = 4;
t.Slot3x3 = 5;
t.VQMM = 7;
t.Sam = 8;
t.BaCay = 9;
t.MauBinh = 10;
t.TLMN = 11;
t.TaLa = 12;
t.Lieng = 13;
t.XiTo = 14;
t.XocXoc = 15;
t.BaiCao = 16;
t.Poker = 17;
t.Bentley = 19;
t.RangeRover = 20;
t.MayBach = 21;
t.RollsRoyce = 22;
t.TaiXiuMD5 = 22e3;
return t;
}();
t.GameId = o;
var s = function() {
function t() {}
t.Deposit = null;
return t;
}();
t.Payment = s;
var a = function() {
function t() {}
t.EVENT_NAME_ACTIVATED_APP = "fb_mobile_activate_app";
t.EVENT_NAME_DEACTIVATED_APP = "fb_mobile_deactivate_app";
t.EVENT_NAME_SESSION_INTERRUPTIONS = "fb_mobile_app_interruptions";
t.EVENT_NAME_TIME_BETWEEN_SESSIONS = "fb_mobile_time_between_sessions";
t.EVENT_NAME_COMPLETED_REGISTRATION = "fb_mobile_complete_registration";
t.EVENT_NAME_COMPLETED_LOGIN = "fb_mobile_complete_login";
t.EVENT_NAME_VIEWED_CONTENT = "fb_mobile_content_view";
t.EVENT_NAME_SEARCHED = "fb_mobile_search";
t.EVENT_NAME_RATED = "fb_mobile_rate";
t.EVENT_NAME_COMPLETED_TUTORIAL = "fb_mobile_tutorial_completion";
t.EVENT_NAME_PUSH_TOKEN_OBTAINED = "fb_mobile_obtain_push_token";
t.EVENT_NAME_ADDED_TO_CART = "fb_mobile_add_to_cart";
t.EVENT_NAME_ADDED_TO_WISHLIST = "fb_mobile_add_to_wishlist";
t.EVENT_NAME_INITIATED_CHECKOUT = "fb_mobile_initiated_checkout";
t.EVENT_NAME_ADDED_PAYMENT_INFO = "fb_mobile_add_payment_info";
t.EVENT_NAME_PURCHASED = "fb_mobile_purchase";
t.EVENT_NAME_EARN_VIRTUAL_CURRENCY = "fb_mobile_earn_virtual_currency";
t.EVENT_NAME_ACHIEVED_LEVEL = "fb_mobile_level_achieved";
t.EVENT_NAME_UNLOCKED_ACHIEVEMENT = "fb_mobile_achievement_unlocked";
t.EVENT_NAME_SPENT_CREDITS = "fb_mobile_spent_credits";
return t;
}();
t.EventFacebook = a;
var r = function() {
function t() {}
t.EVENT_PARAM_CURRENCY = "fb_currency";
t.EVENT_PARAM_REGISTRATION_METHOD = "fb_registration_method";
t.EVENT_PARAM_LOGIN_METHOD = "fb_login_method";
t.EVENT_PARAM_CONTENT_TYPE = "fb_content_type";
t.EVENT_PARAM_CONTENT = "fb_content";
t.EVENT_PARAM_CONTENT_ID = "fb_content_id";
t.EVENT_PARAM_SEARCH_STRING = "fb_search_string";
t.EVENT_PARAM_SUCCESS = "fb_success";
t.EVENT_PARAM_MAX_RATING_VALUE = "fb_max_rating_value";
t.EVENT_PARAM_PAYMENT_INFO_AVAILABLE = "fb_payment_info_available";
t.EVENT_PARAM_NUM_ITEMS = "fb_num_items";
t.EVENT_PARAM_LEVEL = "fb_level";
t.EVENT_PARAM_DESCRIPTION = "fb_description";
t.EVENT_PARAM_SOURCE_APPLICATION = "fb_mobile_launch_source";
t.EVENT_PARAM_VALUE_YES = "1";
t.EVENT_PARAM_VALUE_NO = "0";
return t;
}();
t.ParamsFacebook = r;
var c = function() {
function t() {}
t.ADD_PAYMENT_INFO = "add_payment_info";
t.ADD_TO_CART = "add_to_cart";
t.ADD_TO_WISHLIST = "add_to_wishlist";
t.APP_OPEN = "app_open";
t.BEGIN_CHECKOUT = "begin_checkout";
t.CAMPAIGN_DETAILS = "campaign_details";
t.ECOMMERCE_PURCHASE = "ecommerce_purchase";
t.GENERATE_LEAD = "generate_lead";
t.JOIN_GROUP = "join_group";
t.LEVEL_UP = "level_up";
t.LOGIN = "login";
t.POST_SCORE = "post_score";
t.PRESENT_OFFER = "present_offer";
t.PURCHASE_REFUND = "purchase_refund";
t.SEARCH = "search";
t.SELECT_CONTENT = "select_content";
t.SHARE = "share";
t.SIGN_UP = "sign_up";
t.SPEND_VIRTUAL_CURRENCY = "spend_virtual_currency";
t.TUTORIAL_BEGIN = "tutorial_begin";
t.TUTORIAL_COMPLETE = "tutorial_complete";
t.UNLOCK_ACHIEVEMENT = "unlock_achievement";
t.VIEW_ITEM = "view_item";
t.VIEW_ITEM_LIST = "view_item_list";
t.VIEW_SEARCH_RESULTS = "view_search_results";
t.EARN_VIRTUAL_CURRENCY = "earn_virtual_currency";
t.REMOVE_FROM_CART = "remove_from_cart";
t.CHECKOUT_PROGRESS = "checkout_progress";
t.SET_CHECKOUT_OPTION = "set_checkout_option";
return t;
}();
t.EventFirebase = c;
var l = function() {
function t() {}
t.ACHIEVEMENT_ID = "achievement_id";
t.CHARACTER = "character";
t.TRAVEL_CLASS = "travel_class";
t.CONTENT_TYPE = "content_type";
t.CURRENCY = "currency";
t.COUPON = "coupon";
t.START_DATE = "start_date";
t.END_DATE = "end_date";
t.FLIGHT_NUMBER = "flight_number";
t.GROUP_ID = "group_id";
t.ITEM_CATEGORY = "item_category";
t.ITEM_ID = "item_id";
t.ITEM_LOCATION_ID = "item_location_id";
t.ITEM_NAME = "item_name";
t.LOCATION = "location";
t.LEVEL = "level";
t.SIGN_UP_METHOD = "sign_up_method";
t.NUMBER_OF_NIGHTS = "number_of_nights";
t.NUMBER_OF_PASSENGERS = "number_of_passengers";
t.NUMBER_OF_ROOMS = "number_of_rooms";
t.DESTINATION = "destination";
t.ORIGIN = "origin";
t.PRICE = "price";
t.QUANTITY = "quantity";
t.SCORE = "score";
t.SHIPPING = "shipping";
t.TRANSACTION_ID = "transaction_id";
t.SEARCH_TERM = "search_term";
t.TAX = "tax";
t.VALUE = "value";
t.VIRTUAL_CURRENCY_NAME = "virtual_currency_name";
t.CAMPAIGN = "campaign";
t.SOURCE = "source";
t.MEDIUM = "medium";
t.TERM = "term";
t.CONTENT = "content";
t.ACLID = "aclid";
t.CP1 = "cp1";
t.ITEM_BRAND = "item_brand";
t.ITEM_VARIANT = "item_variant";
t.ITEM_LIST = "item_list";
t.CHECKOUT_STEP = "checkout_step";
t.CHECKOUT_OPTION = "checkout_option";
t.CREATIVE_NAME = "creative_name";
t.CREATIVE_SLOT = "creative_slot";
t.AFFILIATION = "affiliation";
t.INDEX = "index";
t.METHOD = "method";
return t;
}();
t.ParamsFireBase = l;
var u = function() {
function t() {}
t.STRING = "String";
t.DOUBLE = "Double";
return t;
}();
t.ParamType = u;
})(o || (o = {}));
n.default = o;
o.App.init();
cc._RF.pop();
}, {
"./VersionConfig": "VersionConfig"
} ],
DropDownItem: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "0e0c1OzYPVOfpEPKQp433tu", "DropDownItem");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
o(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), s = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var a = cc._decorator, r = a.ccclass, c = a.property, l = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.label = void 0;
e.sprite = void 0;
e.toggle = void 0;
return e;
}
s([ c(cc.Label) ], e.prototype, "label", void 0);
s([ c(cc.Sprite) ], e.prototype, "sprite", void 0);
s([ c(cc.Toggle) ], e.prototype, "toggle", void 0);
return s([ r() ], e);
}(cc.Component);
n.default = l;
cc._RF.pop();
}, {} ],
DropDownOptionData: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "fd5cfBXVIZC4Ks6evy9ygnF", "DropDownOptionData");
var o = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var i = cc._decorator, s = i.ccclass, a = i.property, r = function() {
function t() {
this.optionString = "";
this.optionSf = null;
}
o([ a(cc.String) ], t.prototype, "optionString", void 0);
o([ a(cc.SpriteFrame) ], t.prototype, "optionSf", void 0);
return o([ s("DropDownOptionData") ], t);
}();
n.default = r;
cc._RF.pop();
}, {} ],
DropDown: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "4c73768DrRIEpBrhG+kF/zC", "DropDown");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
o(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), s = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
}, a = this && this.__awaiter || function(t, e, n, o) {
return new (n || (n = Promise))(function(i, s) {
function a(t) {
try {
c(o.next(t));
} catch (t) {
s(t);
}
}
function r(t) {
try {
c(o.throw(t));
} catch (t) {
s(t);
}
}
function c(t) {
t.done ? i(t.value) : (e = t.value, e instanceof n ? e : new n(function(t) {
t(e);
})).then(a, r);
var e;
}
c((o = o.apply(t, e || [])).next());
});
}, r = this && this.__generator || function(t, e) {
var n, o, i, s, a = {
label: 0,
sent: function() {
if (1 & i[0]) throw i[1];
return i[1];
},
trys: [],
ops: []
};
return s = {
next: r(0),
throw: r(1),
return: r(2)
}, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
return this;
}), s;
function r(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(s) {
if (n) throw new TypeError("Generator is already executing.");
for (;a; ) try {
if (n = 1, o && (i = 2 & s[0] ? o.return : s[0] ? o.throw || ((i = o.return) && i.call(o), 
0) : o.next) && !(i = i.call(o, s[1])).done) return i;
(o = 0, i) && (s = [ 2 & s[0], i.value ]);
switch (s[0]) {
case 0:
case 1:
i = s;
break;

case 4:
a.label++;
return {
value: s[1],
done: !1
};

case 5:
a.label++;
o = s[1];
s = [ 0 ];
continue;

case 7:
s = a.ops.pop();
a.trys.pop();
continue;

default:
if (!(i = a.trys, i = i.length > 0 && i[i.length - 1]) && (6 === s[0] || 2 === s[0])) {
a = 0;
continue;
}
if (3 === s[0] && (!i || s[1] > i[0] && s[1] < i[3])) {
a.label = s[1];
break;
}
if (6 === s[0] && a.label < i[1]) {
a.label = i[1];
i = s;
break;
}
if (i && a.label < i[2]) {
a.label = i[2];
a.ops.push(s);
break;
}
i[2] && a.ops.pop();
a.trys.pop();
continue;
}
s = e.call(t, a);
} catch (t) {
s = [ 6, t ];
o = 0;
} finally {
n = i = 0;
}
if (5 & s[0]) throw s[1];
return {
value: s[0] ? s[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./DropDownOptionData"), l = t("./DropDownItem"), u = cc._decorator, p = u.ccclass, _ = u.property, h = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.template = void 0;
e.labelCaption = void 0;
e.spriteCaption = void 0;
e.labelItem = void 0;
e.spriteItem = void 0;
e.optionDatas = [];
e.validTemplate = !1;
e.items = [];
e.isShow = !1;
e._selectedIndex = -1;
return e;
}
Object.defineProperty(e.prototype, "selectedIndex", {
get: function() {
return this._selectedIndex;
},
set: function(t) {
this._selectedIndex = t;
this.refreshShownValue();
},
enumerable: !1,
configurable: !0
});
e.prototype.addOptionDatas = function(t) {
var e = this;
t && t.forEach(function(t) {
e.optionDatas.push(t);
});
this.refreshShownValue();
};
e.prototype.clearOptionDatas = function() {
cc.js.clear(this.optionDatas);
this.optionDatas = new Array();
this.refreshShownValue();
};
e.prototype.show = function() {
if (!this.validTemplate) {
this.setUpTemplate();
if (!this.validTemplate) return;
}
this.isShow = !0;
this._dropDown = this.createDropDownList(this.template);
this._dropDown.name = "DropDown List";
this._dropDown.active = !0;
this._dropDown.setParent(this.template.parent);
var t = this._dropDown.getComponentInChildren(l.default), e = t.node.parent;
t.node.active = !0;
cc.js.clear(this.items);
for (var n = 0, o = this.optionDatas.length; n < o; n++) {
var i = this.optionDatas[n], s = this.addItem(i, n == this.selectedIndex, t, this.items);
if (s) {
s.toggle.isChecked = n == this.selectedIndex;
s.toggle.node.on("toggle", this.onSelectedItem, this);
}
}
t.node.active = !1;
e.height = t.node.height * this.optionDatas.length;
};
e.prototype.addItem = function(t, e, n) {
var o = this.createItem(n);
o.node.setParent(n.node.parent);
o.node.active = !0;
o.node.name = "item_" + (this.items.length + t.optionString ? t.optionString : "");
o.toggle && (o.toggle.isChecked = !1);
o.label && (o.label.string = t.optionString);
if (o.sprite) {
o.sprite.spriteFrame = t.optionSf;
o.sprite.enabled = null != t.optionSf;
}
this.items.push(o);
return o;
};
e.prototype.hide = function() {
this.isShow = !1;
null != this._dropDown && this.delayedDestroyDropdownList(.15);
};
e.prototype.delayedDestroyDropdownList = function() {
return a(this, void 0, void 0, function() {
var t, e;
return r(this, function() {
for (t = 0, e = this.items.length; t < e; t++) null != this.items[t] && this.destroyItem(this.items[t]);
cc.js.clear(this.items);
null != this._dropDown && this.destroyDropDownList(this._dropDown);
this._dropDown = void 0;
return [ 2 ];
});
});
};
e.prototype.destroyItem = function() {};
e.prototype.setUpTemplate = function() {
this.validTemplate = !1;
if (this.template) {
this.template.active = !0;
var t = this.template.getComponentInChildren(cc.Toggle);
this.validTemplate = !0;
if (t && t.node != this.template) if (null == this.labelItem || this.labelItem.node.isChildOf(t.node)) {
if (null != this.spriteItem && !this.spriteItem.node.isChildOf(t.node)) {
this.validTemplate = !1;
cc.error("The dropdown template is not valid. The Item Sprite must be on the item Node or children of it.");
}
} else {
this.validTemplate = !1;
cc.error("The dropdown template is not valid. The Item Label must be on the item Node or children of it.");
} else {
this.validTemplate = !1;
cc.error("The dropdown template is not valid. The template must have a child Node with a Toggle component serving as the item.");
}
if (this.validTemplate) {
var e = t.node.addComponent(l.default);
e.label = this.labelItem;
e.sprite = this.spriteItem;
e.toggle = t;
e.node = t.node;
this.template.active = !1;
this.validTemplate = !0;
} else this.template.active = !1;
} else cc.error("The dropdown template is not assigned. The template needs to be assigned and must have a child GameObject with a Toggle component serving as the item");
};
e.prototype.refreshShownValue = function() {
if (!(this.optionDatas.length <= 0)) {
var t = this.optionDatas[this.clamp(this.selectedIndex, 0, this.optionDatas.length - 1)];
this.labelCaption && (t && t.optionString ? this.labelCaption.string = t.optionString : this.labelCaption.string = "");
if (this.spriteCaption) {
t && t.optionSf ? this.spriteCaption.spriteFrame = t.optionSf : this.spriteCaption.spriteFrame = void 0;
this.spriteCaption.enabled = null != this.spriteCaption.spriteFrame;
}
}
};
e.prototype.createDropDownList = function(t) {
return cc.instantiate(t);
};
e.prototype.destroyDropDownList = function(t) {
t.destroy();
};
e.prototype.createItem = function(t) {
return cc.instantiate(t.node).getComponent(l.default);
};
e.prototype.onSelectedItem = function(t) {
for (var e = t.node.parent, n = 0; n < e.childrenCount; n++) if (e.children[n] == t.node) {
this.selectedIndex = n - 1;
break;
}
this.hide();
null != this.callback && this.callback(this.selectedIndex);
};
e.prototype.setCallBack = function(t) {
this.callback = t;
};
e.prototype.onClick = function() {
this.isShow ? this.hide() : this.show();
};
e.prototype.start = function() {
this.template.active = !1;
this.refreshShownValue();
};
e.prototype.onEnable = function() {
this.node.on("touchend", this.onClick, this);
};
e.prototype.onDisable = function() {
this.node.off("touchend", this.onClick, this);
};
e.prototype.clamp = function(t, e, n) {
return t < e ? e : t > n ? n : t;
};
s([ _(cc.Node) ], e.prototype, "template", void 0);
s([ _(cc.Label) ], e.prototype, "labelCaption", void 0);
s([ _(cc.Sprite) ], e.prototype, "spriteCaption", void 0);
s([ _(cc.Label) ], e.prototype, "labelItem", void 0);
s([ _(cc.Sprite) ], e.prototype, "spriteItem", void 0);
s([ _([ c.default ]) ], e.prototype, "optionDatas", void 0);
return s([ p() ], e);
}(cc.Component);
n.default = h;
cc._RF.pop();
}, {
"./DropDownItem": "DropDownItem",
"./DropDownOptionData": "DropDownOptionData"
} ],
Global: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "488fcGn5YZMzKtipwNuZkTw", "Global");
var o = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
n.Global = void 0;
var i = cc._decorator, s = i.ccclass, a = (i.property, function() {
function t() {}
t.PopupSecurity = null;
t.LobbyController = null;
t.PopupRegister = null;
t.BundleLobby = null;
t.isLoginFromOtherPlaces = !1;
t.LanguageManager = null;
return o([ s ], t);
}());
n.Global = a;
cc._RF.pop();
}, {} ],
HotUpdate: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "2ffa0G2dXNOEK/nOzR1EEZB", "HotUpdate");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
o(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), s = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var a = cc._decorator, r = a.ccclass, c = a.property, l = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.manifestUrl = null;
e.loadingNode = null;
e.bgSplash = [];
e.loadingBar = null;
e.listSprBg = [];
e.lb_Info = null;
e._updating = !1;
e._failCount = 0;
e._canRetry = !1;
e._storagePath = "";
e._updateListener = null;
e._am = null;
e._checkListener = null;
e.versionCompareHandle = null;
e.gameSceneName = "main";
e.loadingGameComp = null;
return e;
}
e.prototype.checkCb = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.loadGame();
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.loadGame();
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.lb_Info.node.active = !0;
this.lb_Info.string = "Đang tải bản cập nhật...";
this.loadingBar.fillRange = 0;
this.hotUpdate();
break;

default:
return;
}
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
t.getMessage();
this.lb_Info.string = "Updating: " + Math.floor(100 * t.getPercent()) + "%";
this.loadingBar.fillRange = t.getPercent();
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._am.downloadFailedAssets();
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.ERROR_DECOMPRESS:
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var o = jsb.fileUtils.getSearchPaths(), i = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(o, i);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(o));
jsb.fileUtils.setSearchPaths(o);
cc.audioEngine.stopAll();
cc.game.restart();
}
};
e.prototype.checkUpdate = function() {
if (this._updating) this.lb_Info.string = "Checking or updating ..."; else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (t = cc.loader.md5Pipe.transformURL(t));
this._am.loadLocalManifest(t);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCb.bind(this));
this._am.checkUpdate();
this._updating = !0;
}
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (t = cc.loader.md5Pipe.transformURL(t));
this._am.loadLocalManifest(t);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
} else {
var e = this;
this.scheduleOnce(function() {
e.hotUpdate();
}, .5);
}
};
e.prototype.onLoad = function() {
this.loadingGameComp = this.loadingNode.getComponent("Loading");
if (!cc.sys.isNative && cc.sys.isBrowser || cc.sys.os === cc.sys.OS_OSX) this.loadGame(); else {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-asset";
this.versionCompareHandle = function(t, e) {
for (var n = t.split("."), o = e.split("."), i = 0; i < n.length; ++i) {
var s = parseInt(n[i]), a = parseInt(o[i] || 0);
if (s !== a) return s - a;
}
return o.length > n.length ? -1 : 0;
};
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
this._am.setVerifyCallback(function(t, e) {
e.compressed, e.md5, e.path, e.size;
return !0;
});
cc.sys.os === cc.sys.OS_ANDROID && this._am.setMaxConcurrentTask(10);
this.checkUpdate();
}
};
e.prototype.start = function() {
cc.sys.isBrowser;
};
e.prototype.loadGame = function() {
this.loadingGameComp.startGame();
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
s([ c({
type: cc.Asset
}) ], e.prototype, "manifestUrl", void 0);
s([ c(cc.Node) ], e.prototype, "loadingNode", void 0);
s([ c([ cc.SpriteFrame ]) ], e.prototype, "bgSplash", void 0);
s([ c(cc.Sprite) ], e.prototype, "loadingBar", void 0);
s([ c([ cc.SpriteFrame ]) ], e.prototype, "listSprBg", void 0);
s([ c(cc.Label) ], e.prototype, "lb_Info", void 0);
return s([ r ], e);
}(cc.Component);
n.default = l;
cc._RF.pop();
}, {} ],
Http: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "2cd84ecMG9CWL/aifwSEhhY", "Http");
var o = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var i = t("../../Loading/src/Configs"), s = t("./VersionConfig"), a = cc._decorator, r = a.ccclass, c = (a.property, 
function() {
function t() {}
t.post = function(t, e, n, o) {
void 0 === o && (o = !1);
var i = new XMLHttpRequest(), s = "";
if (null !== e) {
var a = 0, r = Object.keys(e).length;
for (var c in e) {
if (e.hasOwnProperty(c)) {
s += c + "=" + e[c];
a < r - 1 && (s += "&");
}
a++;
}
}
i.onreadystatechange = function() {
if (4 === i.readyState) if (200 === i.status) {
var t = null, e = null;
try {
t = JSON.parse(i.responseText);
} catch (t) {
e = t;
}
n(e, t);
} else n(i.status, null);
};
i.open("POST", t, !0);
i.setRequestHeader("Content-type", "application/json");
o ? i.send(JSON.stringify(e)) : i.send(s);
};
t.postz = function(t, e, n) {
var o = new XMLHttpRequest(), i = "";
if (null !== e) {
var s = 0, a = Object.keys(e).length;
for (var r in e) {
if (e.hasOwnProperty(r)) {
i += r + "=" + e[r];
s < a - 1 && (i += "&");
}
s++;
}
}
o.onreadystatechange = function() {
if (4 === o.readyState) if (200 === o.status) {
var t = null, e = null;
try {
t = JSON.parse(o.responseText);
} catch (t) {
e = t;
}
n(e, t);
} else n(o.status, null);
};
o.open("POST", encodeURI(t), !0);
o.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
o.send(i);
};
t.get = function(t, e, n) {
var o = new XMLHttpRequest(), a = "";
e = e || {};
s.default.CPName;
e.hasOwnProperty("cp") || (e.cp = "R");
e.cl = "R";
cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID ? e.pf = "ad" : cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS ? e.pf = "ios" : cc.sys.isNative ? e.pf = "other" : e.pf = "web";
e.at = i.default.Login.AccessToken;
if (null !== e) {
var r = 0, c = Object.keys(e).length;
for (var l in e) if (e.hasOwnProperty(l)) {
a += l + "=" + e[l];
r++ < c - 1 && (a += "&");
}
}
o.onreadystatechange = function() {
if (4 === o.readyState) if (200 === o.status) {
var t = null, e = null;
try {
t = JSON.parse(o.responseText);
} catch (t) {
e = t;
}
n(e, t);
} else n(o.status, null);
};
var u = t + "?" + a;
o.open("GET", u, !0);
o.send();
};
return o([ r ], t);
}());
n.default = c;
cc._RF.pop();
}, {
"../../Loading/src/Configs": "Configs",
"./VersionConfig": "VersionConfig"
} ],
Loading: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "06c935DvwpCJ5nCCvhzAwFf", "Loading");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
o(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), s = this && this.__decorate || function(t, e, n, o) {
var i, s = arguments.length, a = s < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (s < 3 ? i(a) : s > 3 ? i(e, n, a) : i(e, n)) || a);
return s > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var a = t("../../Loading/src/Http"), r = t("./BundleControl"), c = t("./Configs"), l = t("./Global"), u = t("./UtilsNative"), p = cc._decorator, _ = p.ccclass, h = p.property, f = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.lblStatus = null;
e.lbTips = null;
e.nodeSlider = null;
e.spriteProgress = null;
e.listSkeData = [];
e.listTips = [ {
vi: "Đăng nhập hàng ngày để nhận thưởng Điểm Danh!",
en: "Dont forget login every day to get free attendance bonus!"
}, {
vi: "Tiến Lên Miền Nam: Chống gian lận,an toàn tuyệt đối",
en: "Killer 13: Anti cheating,absolute safety"
}, {
vi: "Nạp đầu nhận thưởng lên tới 790K",
en: "First cash-in can receive bonus up to 790K"
}, {
vi: "Bộ phận chăm sóc khách hàng luôn online 24/24!",
en: "Customer care team support online 24/24!"
}, {
vi: "Win365 nạp rút nhanh chóng và an toàn!",
en: "W79 quick cashin,cashout and alway safety!"
} ];
return e;
}
e.prototype.start = function() {
cc.assetManager.downloader.maxConcurrency = 20;
cc.assetManager.downloader.maxRequestsPerFrame = 6;
this.showTips();
};
e.prototype.startGame = function() {
var t = this;
this.lblStatus.string = "Tải tài nguyên từ máy chủ...";
this.spriteProgress.fillRange = 0;
this.nodeSlider.progress = 0;
0 == c.default.App.IS_LOCAL ? a.default.get("https://365win.club/assets/AssetBundleVersion.json", {}, function(e, n) {
r.default.init(n);
t.loadLobby();
}) : this.loadLobby();
u.default.getDeviceId();
};
e.prototype.loadScriptCore = function() {
var t = this;
r.default.loadBundle("ScriptCore", function() {
t.loadLobby();
});
};
e.prototype.loadLobby = function() {
var t = this, e = this;
new Date().getTime();
r.default.loadBundle("Lobby", function(n) {
l.Global.BundleLobby = n;
for (var o = t.listSkeData.length, i = 0; i < o; i++) {
var s = t.listSkeData[i];
n.load(s, sp.SkeletonData, function() {});
}
n.loadScene("Lobby", function(t, n) {
e.lblStatus.string = "Loading: " + parseInt(t / n * 100) + "%";
e.spriteProgress.fillRange = t / n;
e.nodeSlider.progress = e.spriteProgress.fillRange;
}, function(t, e) {
cc.sys.localStorage.setItem("SceneLobby", e);
cc.director.runScene(e);
new Date().getTime();
});
n.loadDir("PrefabPopup", cc.Prefab, function() {});
});
};
e.prototype.showTips = function() {
var t = this;
this.schedule(function() {
t.lbTips.string = t.getStrTips();
}, 3, cc.macro.REPEAT_FOREVER, .1);
};
e.prototype.getStrTips = function() {
var t = cc.sys.localStorage.getItem("langCode");
null == t && (t = "vi");
return this.listTips[this.randomRangeInt(0, this.listTips.length)][t];
};
e.prototype.randomRangeInt = function(t, e) {
return Math.floor(Math.random() * (e - t)) + t;
};
s([ h(cc.Label) ], e.prototype, "lblStatus", void 0);
s([ h(cc.Label) ], e.prototype, "lbTips", void 0);
s([ h(cc.Slider) ], e.prototype, "nodeSlider", void 0);
s([ h(cc.Sprite) ], e.prototype, "spriteProgress", void 0);
return s([ _ ], e);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {
"../../Loading/src/Http": "Http",
"./BundleControl": "BundleControl",
"./Configs": "Configs",
"./Global": "Global",
"./UtilsNative": "UtilsNative"
} ],
"LogEvent.Facebook": [ function(t, e, n) {
"use strict";
cc._RF.push(e, "4ca09lb5WpN1qyZP0SX7eS4", "LogEvent.Facebook");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = t("../Configs"), i = function() {
function t() {}
t.getInstance = function() {
null == this.instance && (this.instance = new t());
return this.instance;
};
t.prototype.isUseSDK = function() {
return !(!cc.sys.isNative || cc.sys.os != cc.sys.OS_ANDROID && cc.sys.os != cc.sys.OS_IOS);
};
t.prototype.facebookCustomLogsEvent = function(t, e, n) {
void 0 === n && (n = null);
};
t.prototype.createEventParam = function(t, e, n) {
void 0 === n && (n = null);
void 0 !== n && null != n || (n = o.default.ParamType.STRING);
return {
key: t,
value: e,
typeValue: n
};
};
t.prototype.sendEventSdt = function(t) {
var e = [];
e.push(this.createEventParam("phone", t));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_ADDED_PAYMENT_INFO, e);
};
t.prototype.sendEventSigupSuccess = function(t) {
var e = [];
e.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_REGISTRATION_METHOD, t));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_COMPLETED_REGISTRATION, e);
};
t.prototype.sendEventLogin = function(t) {
var e = [];
e.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_LOGIN_METHOD, t, o.default.ParamType.STRING));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_COMPLETED_LOGIN, e);
};
t.prototype.sendEventOpenApp = function() {};
t.prototype.sendEventPurchase = function(t, e) {
var n = [];
n.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_CURRENCY, t, o.default.ParamType.STRING));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_PURCHASED, n, e);
};
t.prototype.sendEventMoneyChange = function(t, e, n) {
var i = [];
i.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_CONTENT, t, o.default.ParamType.STRING));
i.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_CURRENCY, e, o.default.ParamType.STRING));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_SPENT_CREDITS, i, n);
};
t.prototype.sendEventCashout = function(t, e) {
var n = [];
n.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_CURRENCY, t, o.default.ParamType.STRING));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_EARN_VIRTUAL_CURRENCY, n, e);
};
t.prototype.sendEventClickShop = function(t, e) {
var n = [];
n.push(this.createEventParam(o.default.ParamsFacebook.EVENT_PARAM_CURRENCY, t, o.default.ParamType.STRING));
this.facebookCustomLogsEvent(o.default.EventFacebook.EVENT_NAME_INITIATED_CHECKOUT, n, e);
};
t.instance = null;
return t;
}();
n.default = i;
cc._RF.pop();
}, {
"../Configs": "Configs"
} ],
"LogEvent.FireBase": [ function(t, e, n) {
"use strict";
cc._RF.push(e, "2c4f2kkOwdER7tJkWRSAYzr", "LogEvent.FireBase");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = t("../Configs"), i = function() {
function t() {}
t.getInstance = function() {
null == this.instance && (this.instance = new t());
return this.instance;
};
t.prototype.isUseSDK = function() {
return !(!cc.sys.isNative || cc.sys.os != cc.sys.OS_ANDROID && cc.sys.os != cc.sys.OS_IOS);
};
t.prototype.onClickSendLogEvent = function() {};
t.prototype.firebaseSendLogEvent = function() {};
t.prototype.sendEventSdt = function(t) {
var e = {};
e.phone = t;
this.firebaseSendLogEvent(o.default.EventFirebase.ADD_PAYMENT_INFO, e);
};
t.prototype.sendEventSigupSuccess = function(t) {
var e = {};
e[o.default.ParamsFireBase.METHOD] = t;
this.firebaseSendLogEvent(o.default.EventFirebase.SIGN_UP, e);
};
t.prototype.sendEventLogin = function(t) {
var e = {};
e[o.default.ParamsFireBase.METHOD] = t;
this.firebaseSendLogEvent(o.default.EventFirebase.LOGIN, e);
};
t.prototype.sendEventOpenApp = function() {
var t = {};
t[o.default.ParamsFireBase.CONTENT] = "1";
this.firebaseSendLogEvent(o.default.EventFirebase.APP_OPEN, t);
};
t.prototype.sendEventPurchase = function(t, e) {
var n = {};
n[o.default.ParamsFireBase.CURRENCY] = t;
n[o.default.ParamsFireBase.VALUE] = e;
this.firebaseSendLogEvent(o.default.EventFirebase.ECOMMERCE_PURCHASE, n);
};
t.prototype.sendEventMoneyChange = function(t, e, n) {
var i = {};
i[o.default.ParamsFireBase.ITEM_NAME] = t;
i[o.default.ParamsFireBase.VIRTUAL_CURRENCY_NAME] = e;
i[o.default.ParamsFireBase.VALUE] = n;
this.firebaseSendLogEvent(o.default.EventFirebase.SPEND_VIRTUAL_CURRENCY, i);
};
t.prototype.sendEventCashout = function(t, e) {
var n = {};
n[o.default.ParamsFireBase.VIRTUAL_CURRENCY_NAME] = t;
n[o.default.ParamsFireBase.VALUE] = e;
this.firebaseSendLogEvent(o.default.EventFirebase.EARN_VIRTUAL_CURRENCY, n);
};
t.prototype.sendEventClickShop = function(t, e) {
var n = {};
n[o.default.ParamsFireBase.CURRENCY] = t;
n[o.default.ParamsFireBase.VALUE] = e;
this.firebaseSendLogEvent(o.default.EventFirebase.BEGIN_CHECKOUT, n);
};
t.instance = null;
return t;
}();
n.default = i;
cc._RF.pop();
}, {
"../Configs": "Configs"
} ],
LogEvent: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "8582fS1gU1D1Lp+gCCJai7n", "LogEvent");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = t("../Configs"), i = t("./LogEvent.Facebook"), s = t("./LogEvent.FireBase"), a = function() {
function t() {}
t.getInstance = function() {
null == this.instance && (this.instance = new t());
return this.instance;
};
t.prototype.createEventParam = function(t, e, n) {
void 0 === n && (n = null);
void 0 !== n && null != n || (n = o.default.ParamType.STRING);
return {
key: t,
value: e,
typeValue: n
};
};
t.prototype.sendEventSdt = function(t) {
i.default.getInstance().sendEventSdt(t);
s.default.getInstance().sendEventSdt(t);
};
t.prototype.sendEventSigupSuccess = function(t) {
i.default.getInstance().sendEventSigupSuccess(t);
s.default.getInstance().sendEventSigupSuccess(t);
};
t.prototype.sendEventLogin = function(t) {
i.default.getInstance().sendEventLogin(t);
s.default.getInstance().sendEventLogin(t);
};
t.prototype.sendEventOpenApp = function() {
s.default.getInstance().sendEventOpenApp();
};
t.prototype.sendEventPurchase = function(t, e) {
i.default.getInstance().sendEventPurchase(t, e);
s.default.getInstance().sendEventPurchase(t, e);
};
t.prototype.sendEventMoneyChange = function(t, e, n) {
i.default.getInstance().sendEventMoneyChange(t, e, n);
s.default.getInstance().sendEventMoneyChange(t, e, n);
};
t.prototype.sendEventCashout = function(t, e) {
i.default.getInstance().sendEventCashout(t, e);
s.default.getInstance().sendEventCashout(t, e);
};
t.prototype.sendEventClickShop = function(t, e) {
i.default.getInstance().sendEventClickShop(t, e);
s.default.getInstance().sendEventClickShop(t, e);
};
t.instance = null;
return t;
}();
n.default = a;
cc._RF.pop();
}, {
"../Configs": "Configs",
"./LogEvent.Facebook": "LogEvent.Facebook",
"./LogEvent.FireBase": "LogEvent.FireBase"
} ],
UtilsNative: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "336b2+HbC9HMZQobmyH8RwZ", "UtilsNative");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = t("./Global");
cc.NativeCallJS = function(t, e) {
switch (t + "") {
case "1":
case "2":
break;

case "3":
var n = e;
o.Global.PopupSecurity.actGetOtpServer(n);
break;

case "4":
var i = e;
o.Global.PopupSecurity.actGetVerifyCode(i);
}
};
var i = function() {
function t() {}
t.onCallNative = function() {
cc.sys.os === cc.sys.OS_ANDROID && cc.sys.isNative || cc.sys.os === cc.sys.OS_IOS && cc.sys.isNative;
};
t.sendLogEvent = function(t) {
this.onCallNative("1", JSON.stringify(t));
};
t.getDeviceId = function() {
cc.sys.os == cc.sys.OS_ANDROID || (cc.sys.os, cc.sys.OS_IOS);
};
t.verifyPhone = function(t) {
this.onCallNative("3", t);
};
t.verifyOTP = function(t) {
this.onCallNative("4", t);
};
t.httpGet = function(t, e) {
var n = new XMLHttpRequest();
n.onreadystatechange = function() {
if (4 === n.readyState) if (200 === n.status) {
var t = null, o = null;
try {
t = JSON.parse(n.responseText);
} catch (t) {
o = t;
}
e(o, t);
} else e(n.status, null);
};
n.open("GET", t, !0);
n.send();
};
t.copyClipboard = function(t) {
this.onCallNative("5", t);
};
return t;
}();
n.default = i;
cc._RF.pop();
}, {
"./Global": "Global"
} ],
VersionConfig: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "4432dTxaiNCLKzaQM0wvnBN", "VersionConfig");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = function() {
function t() {}
t.CP_NAME_F69 = "F69";
t.ENV_DEV = "dev";
t.ENV_PROD = "prod";
t.DOMAIN_DEV = "365win.club";
t.DOMAIN_PRO = "365win.club";
t.VersionName = "";
t.CPName = "";
t.ENV = t.ENV_DEV;
return t;
}();
n.default = o;
if (cc.sys.isNative) {
var i = cc.sys.localStorage.getItem("VersionConfig");
if (null != i) {
i = JSON.parse(i);
o.VersionName = i.VersionName;
o.CPName = i.CPName;
} else {
o.VersionName = "1.0.0";
o.CPName = o.CP_NAME_F69;
}
} else {
o.VersionName = "1.0.0";
o.CPName = o.CP_NAME_F69;
}
cc._RF.pop();
}, {} ]
}, {}, [ "BundleControl", "Configs", "DropDown", "DropDownItem", "DropDownOptionData", "Global", "HotUpdate", "Http", "Loading", "LogEvent.Facebook", "LogEvent.FireBase", "LogEvent", "UtilsNative", "VersionConfig" ]);